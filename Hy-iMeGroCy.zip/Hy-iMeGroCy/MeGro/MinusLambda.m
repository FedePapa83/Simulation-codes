function J = MinusLambda(var)

    global ferm c_glcex;
    global nu_rib;
    global c_AXP;

    global kcat_hxt kcat_gly kcat_rib kcat_resp kcat_ferm;
    global kcat_resp2 kcat_gly2;

    global KM_hxt KM_gly KM_rib KM_resp KM_ferm KM_gly_ADP KM_resp_ADP KM_rib_ATP;
    global KM_resp2 KM_resp2_ADP KM_gly2 KM_gly2_ATP;

    global KI_pyr KI_glcin KI2_glcin;

    global s_1 s_2 s_3 s_4 s_5 s_6 s_7 s_8 s_9 s_10 s_11 s_12;

    c_glcin  = var(1);
    c_pyr    = var(2);
    c_ATP    = var(3);
    c_ADP    = c_AXP - c_ATP;
    c_EtOHin = var(4);
    
    g_hxt   = kcat_hxt * c_glcex / ( (c_glcex + KM_hxt) * (1 + c_glcin/KI_glcin) );
    g_gly   = kcat_gly * c_glcin * c_ADP / ( (c_glcin + KM_gly) * (c_ADP + KM_gly_ADP) * (1 + c_pyr/KI_pyr) );
    g_gly2  = kcat_gly2 * c_EtOHin * c_ATP / ( (c_EtOHin + KM_gly2) * (c_ATP + KM_gly2_ATP) * (1 + c_glcin/KI2_glcin) );
    g_rib   = kcat_rib * c_pyr * c_ATP / ( (c_pyr + KM_rib) * (c_ATP + KM_rib_ATP) );
    g_resp  = kcat_resp * c_pyr * c_ADP / ( (c_pyr + KM_resp) * (c_ADP + KM_resp_ADP) );
    g_resp2 = kcat_resp2 * c_EtOHin * c_ADP / ( (c_EtOHin + KM_resp2) * (c_ADP + KM_resp2_ADP) );
    g_ferm  = kcat_ferm * c_pyr / (c_pyr + KM_ferm);   

    eta  = g_gly2/g_gly;   
    xi   = g_resp2/g_resp;

    nu_resp  = nu_rib * (1-ferm) * (s_4*s_9 - s_7*(s_8+s_12*eta)) / ( ferm*(1+xi)*s_6*(s_8+s_12*eta) - (1-ferm)*(s_4*(s_10+s_11*xi) - s_5*(s_8+s_12*eta)) );
    nu_ferm  = ( (s_4*(s_10+s_11*xi) - s_5*(s_8+s_12*eta))*nu_resp + (s_4*s_9 - s_7*(s_8+s_12*eta))*nu_rib ) / (s_6*(s_8+s_12*eta));  
    nu_gly   = ( -(s_10+s_11*xi)*nu_resp - s_9*nu_rib ) / (s_8+s_12*eta);
    nu_hxt   = - ((s_2+s_3*eta)/s_1)*nu_gly;

    c_hxt  = nu_hxt/g_hxt;
    c_gly  = nu_gly/g_gly;
    c_rib  = nu_rib/g_rib;
    c_resp = nu_resp/g_resp;
    c_ferm = nu_ferm/g_ferm;

    J = - nu_rib/(c_hxt + c_gly + c_rib + c_resp + c_ferm);

end

