function [X, G, CYF, G1S, CLNB, S1, Eta, MA, PDET] = Generation_CI(P_0, G_0, CYF_0, G1S_0, CLNB_0, S1_0, Eta_0, Sigma_0, MA_0, PDET_0, VP, VIC, VTB, nw, nd ,nrr)

    co = .0001;
    
    %Whi5 coefficients for the variation of k_14, k_21 with respect to the genealogica age of parent and daugther cells  
    coeff_k14_P=[0.105 0.105 0.105 0.105 0.105 0.105 0.105];       %2%
    coeff_k21_P=[86 86 86 86 86 86 86];                            %2%
    
    coeff_k14_D=[1 0.445 0.196 0.196 0.178 0.169 0.167];           %2%
    coeff_k21_D=[1.57 40 50 60 60 60 60];                          %2%
    
    
    %Sic1 coefficients for the variation of k_31, k_33, k_37, k_39, k_43 with respect to the genealogica age of parent and daugther cells  
     coeff_k31_P=[0.2 0.2 0.2 0.2 0.2 0.2 0.2];                    %2%
     coeff_k33_P=[0.2 0.2 0.2 0.2 0.2 0.2 0.2];                    %2%
     coeff_k37_P=[0.2 0.2 0.2 0.2 0.2 0.2 0.2];                    %2%
     coeff_k39_P=[0.2 0.2 0.2 0.2 0.2 0.2 0.2];                    %2% 
     coeff_k43_P=[80 80 80 80 80 80 80];                           %2%

     coeff_k31_D=[1 1 0.8 0.35 0.25 0.209 0.2];                    %2%
     coeff_k33_D=[1 1 0.8 0.35 0.25 0.209 0.2];                    %2%
     coeff_k37_D=[1 1 0.8 0.35 0.25 0.209 0.2];                    %2%
     coeff_k39_D=[1 1 0.8 0.35 0.25 0.209 0.2];                    %2%
     coeff_k43_D=[0.44 1.6 45 60 70 78 80];                        %2%

    
    %Variation of the initial amount of Sic1 with respect to daughter and parent cells
    coeff_Sic1_tot_P=[1.4/3 1.4/3 1.4/3 1.4/3 1.4/3 1.4/3 1.4/3]; %2%
    
    coeff_Sic1_tot_D=[1.9/3 1.9/3 1.9/3 1.9/3 1.9/3 1.9/3 1.9/3]; %2%

    
    G    = max(co*G_0,G_0.*(1+VP*randn(size(G_0,2),1)'))';
    CYF  = max(co*CYF_0,CYF_0.*(1+VP*randn(size(CYF_0,2),1)'))';
    G1S  = max(co*G1S_0,G1S_0.*(1+VP*randn(size(G1S_0,2),1)'))';

    if PDET_0(1)==0     %Parent
        if PDET_0(2) <= 7
            G1S(4)       = max(co*(coeff_k14_P(PDET_0(2))*G1S_0(4)),(coeff_k14_P(PDET_0(2))*G1S_0(4))*(1+VP*randn(size(G1S_0(4),2),1)'))';            %Modifica parametro k14
            G1S(15:end)  = max(co*(coeff_k21_P(PDET_0(2))*G1S(15:end)),(coeff_k21_P(PDET_0(2))*G1S(15:end)).*(1+VP*randn(size(G1S(15:end),2),1)'))';  %Modifica parametri k21_tot        
        else
            G1S(4)       = max(co*(coeff_k14_P(7)*G1S_0(4)),(coeff_k14_P(7)*G1S_0(4))*(1+VP*randn(size(G1S_0(4),2),1)'))';            %Modifica parametro k14
            G1S(15:end)  = max(co*(coeff_k21_P(7)*G1S(15:end)),(coeff_k21_P(7)*G1S(15:end)).*(1+VP*randn(size(G1S(15:end),2),1)'))';  %Modifica parametri k21_tot
        end
    else                %Daughter
        if PDET_0(2) <= 7
            G1S(4)       = max(co*(coeff_k14_D(PDET_0(2))*G1S_0(4)),(coeff_k14_D(PDET_0(2))*G1S_0(4))*(1+VP*randn(size(G1S_0(4),2),1)'))';            %Modifica parametro k14
            G1S(15:end)  = max(co*(coeff_k21_D(PDET_0(2))*G1S(15:end)),(coeff_k21_D(PDET_0(2))*G1S(15:end)).*(1+VP*randn(size(G1S(15:end),2),1)'))';  %Modifica parametri k21_tot        
        else
            G1S(4)       = max(co*(coeff_k14_D(7)*G1S_0(4)),(coeff_k14_D(7)*G1S_0(4))*(1+VP*randn(size(G1S_0(4),2),1)'))';            %Modifica parametro k14
            G1S(15:end)  = max(co*(coeff_k21_D(7)*G1S(15:end)),(coeff_k21_D(7)*G1S(15:end)).*(1+VP*randn(size(G1S(15:end),2),1)'))';  %Modifica parametri k21_tot
        end
    end
    
    CLNB = max(co*CLNB_0,CLNB_0.*(1+VP*randn(size(CLNB_0,2),1)'))';
        
    S1   = max(co*S1_0,S1_0.*(1+VP*randn(size(S1_0,2),1)'))';
    
    if PDET_0(1)==0     %Parent
        if PDET_0(2) <= 7
            S1(2)       = max(co*(coeff_k31_P(PDET_0(2))*S1_0(2)),(coeff_k31_P(PDET_0(2))*S1_0(2))*(1+VP*randn(size(S1_0(2),2),1)'))';            %Modifica parametro k31
            S1(4)       = max(co*(coeff_k33_P(PDET_0(2))*S1_0(4)),(coeff_k33_P(PDET_0(2))*S1_0(4))*(1+VP*randn(size(S1_0(4),2),1)'))';            %Modifica parametro k33
            S1(6)       = max(co*(coeff_k37_P(PDET_0(2))*S1_0(6)),(coeff_k37_P(PDET_0(2))*S1_0(6))*(1+VP*randn(size(S1_0(6),2),1)'))';            %Modifica parametro k37
            S1(8)       = max(co*(coeff_k39_P(PDET_0(2))*S1_0(8)),(coeff_k39_P(PDET_0(2))*S1_0(8))*(1+VP*randn(size(S1_0(8),2),1)'))';            %Modifica parametro k39
            S1(end)     = max(co*(coeff_k43_P(PDET_0(2))*S1_0(end)),(coeff_k43_P(PDET_0(2))*S1_0(end))*(1+VP*randn(size(S1_0(end),2),1)'))';      %Modifica parametro k43        
        else
            S1(2)       = max(co*(coeff_k31_P(7)*S1_0(2)),(coeff_k31_P(7)*S1_0(2))*(1+VP*randn(size(S1_0(2),2),1)'))';            %Modifica parametro k31
            S1(4)       = max(co*(coeff_k33_P(7)*S1_0(4)),(coeff_k33_P(7)*S1_0(4))*(1+VP*randn(size(S1_0(4),2),1)'))';            %Modifica parametro k33
            S1(6)       = max(co*(coeff_k37_P(7)*S1_0(6)),(coeff_k37_P(7)*S1_0(6))*(1+VP*randn(size(S1_0(6),2),1)'))';            %Modifica parametro k37
            S1(8)       = max(co*(coeff_k39_P(7)*S1_0(8)),(coeff_k39_P(7)*S1_0(8))*(1+VP*randn(size(S1_0(8),2),1)'))';            %Modifica parametro k39
            S1(end)     = max(co*(coeff_k43_P(7)*S1_0(end)),(coeff_k43_P(7)*S1_0(end))*(1+VP*randn(size(S1_0(end),2),1)'))';      %Modifica parametro k43
        end
    else                %Daughter
        if PDET_0(2) <= 7
            S1(2)       = max(co*(coeff_k31_D(PDET_0(2))*S1_0(2)),(coeff_k31_D(PDET_0(2))*S1_0(2))*(1+VP*randn(size(S1_0(2),2),1)'))';            %Modifica parametro k31
            S1(4)       = max(co*(coeff_k33_D(PDET_0(2))*S1_0(4)),(coeff_k33_D(PDET_0(2))*S1_0(4))*(1+VP*randn(size(S1_0(4),2),1)'))';            %Modifica parametro k33
            S1(6)       = max(co*(coeff_k37_D(PDET_0(2))*S1_0(6)),(coeff_k37_D(PDET_0(2))*S1_0(6))*(1+VP*randn(size(S1_0(6),2),1)'))';            %Modifica parametro k37
            S1(8)       = max(co*(coeff_k39_D(PDET_0(2))*S1_0(8)),(coeff_k39_D(PDET_0(2))*S1_0(8))*(1+VP*randn(size(S1_0(8),2),1)'))';            %Modifica parametro k39
            S1(end)     = max(co*(coeff_k43_D(PDET_0(2))*S1_0(end)),(coeff_k43_D(PDET_0(2))*S1_0(end))*(1+VP*randn(size(S1_0(end),2),1)'))';      %Modifica parametro k43        
        else
            S1(2)       = max(co*(coeff_k31_D(7)*S1_0(2)),(coeff_k31_D(7)*S1_0(2))*(1+VP*randn(size(S1_0(2),2),1)'))';            %Modifica parametro k31
            S1(4)       = max(co*(coeff_k33_D(7)*S1_0(4)),(coeff_k33_D(7)*S1_0(4))*(1+VP*randn(size(S1_0(4),2),1)'))';            %Modifica parametro k33
            S1(6)       = max(co*(coeff_k37_D(7)*S1_0(6)),(coeff_k37_D(7)*S1_0(6))*(1+VP*randn(size(S1_0(6),2),1)'))';            %Modifica parametro k37
            S1(8)       = max(co*(coeff_k39_D(7)*S1_0(8)),(coeff_k39_D(7)*S1_0(8))*(1+VP*randn(size(S1_0(8),2),1)'))';            %Modifica parametro k39
            S1(end)     = max(co*(coeff_k43_D(7)*S1_0(end)),(coeff_k43_D(7)*S1_0(end))*(1+VP*randn(size(S1_0(end),2),1)'))';      %Modifica parametro k43
        end
    end
       
    Eta = zeros(size(Eta_0,2),1)';
    for i = 1:size(Eta_0,2);
        MU     = log(Eta_0(i)^2 / sqrt(Sigma_0(i)+Eta_0(i)^2));
        SIGMA  = sqrt(log(Sigma_0(i)/Eta_0(i)^2 + 1));
        Eta(i) = lognrnd(MU,SIGMA);
    end

    %Eta = Eta_0;
    
    MA = max(co*MA_0,MA_0*(1+VIC*randn))';
    
    if PDET_0(1)==0     %Parent
        if PDET_0(2) <= 7
            MA(end) = max(co*(coeff_Sic1_tot_P(PDET_0(2))*MA_0(end)),(coeff_Sic1_tot_P(PDET_0(2))*MA_0(end))*(1+VIC*randn))';
        else
            MA(end) = max(co*(coeff_Sic1_tot_P(7)*MA_0(end)),(coeff_Sic1_tot_P(7)*MA_0(end))*(1+VIC*randn))';
        end
    else                %Daughter
        if PDET_0(2) <= 7
            MA(end) = max(co*(coeff_Sic1_tot_D(PDET_0(2))*MA_0(end)),(coeff_Sic1_tot_D(PDET_0(2))*MA_0(end))*(1+VIC*randn))';
        else
            MA(end) = max(co*(coeff_Sic1_tot_D(7)*MA_0(end)),(coeff_Sic1_tot_D(7)*MA_0(end))*(1+VIC*randn))';
        end
    end

    P0 = P_0;
    R0              = G(19)*P0;
    Cln3_ER_0       = G(22)*P0;
    Far1_0          = MA(1);
    Whi5_phospho_0  = [MA(4);zeros(nw,1)];
    Sic1_n_0        = MA(6);
    Pd_0	= [1;zeros(nd-1,1)];
    Pr_0    = [1;zeros(nrr-1,1)];

    X  = [P0; R0; Cln3_ER_0; 0; 0; 0; 0; Far1_0; 0; 0; 0; 0; 0; 0; 0; 0; Sic1_n_0; 0; 0; 0; 0; 0; Pd_0; Pr_0; Whi5_phospho_0];

    PDET = PDET_0;
    Tb   = 85*(1+VTB*randn);                                %2%
    PDET(5) = Tb*20/100;
    PDET(4) = Tb - PDET(5);

end
