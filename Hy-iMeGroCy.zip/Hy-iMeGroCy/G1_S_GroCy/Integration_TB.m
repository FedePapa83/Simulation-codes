function [dX, PDET, Protein, Timer]= Integration_TB(X, G, PDET, dt, i, Protein, Timer)

    PDET(11) = i;    

    nX = length(X);

    P               = X(1);
    R               = X(2);

    dP = G(2)*R - P/G(11);
    dR = G(1)*max(0,G(19)*P-R) - R/G(10);
    dX  = [dP;dR;zeros(nX-2,1)];
    
    if PDET(6) == 2 && i > PDET(4)/dt + PDET(8) 
        PDET(6) = 3;
        PDET(9) = i; 
    elseif PDET(6) == 3 && i > (PDET(4) + PDET(5))/dt + PDET(8) 
        PDET(6)  = 4;
        PDET(10) = i; 
        Protein(3) = P; %Pcd content
        Timer(5) = (i- PDET(3))*dt;  %Cycle length 
    end

end
