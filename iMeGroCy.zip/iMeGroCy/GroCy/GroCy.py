import random
import string
from itertools import chain
import numpy as np
import pandas as pd
from scipy.integrate import odeint
import matplotlib.pyplot as plt
import multiprocessing as mp
import os
import math
import tkinter as tk
from tkinter import filedialog
from datetime import datetime
startTime = datetime.now()

class Cell:

    def __init__(self, param_set, t_lim, status, id_cell, tree_cell, id_parent, t_offset):

        self.par = param_set
        self.t_lim = t_lim
        self.t_offset = [t_offset]
        self.x_start = [status['R'], status['P'], status['Cln3Far1'], status['Far1'], status['Cln3nuc']]
        self.R_cycle, self.P_cycle, self.Cln3Far1_cycle, self.Far1_cycle, self.Cln3nuc_cycle, self.Cln3tot_cycle, self.Cln3cyt_cycle, self.t_cycle = (np.array([]) for i in range(8))
        self.bud = []
        self.t1a_flag = False
        self.restart_status = {}
        self.id_cell = id_cell
        self.id_parent = id_parent
        self.id_daughters = []
        self.tree_cell = tree_cell

        if 'depth' in status:
            self.tree_depth = status['depth']
        else:
            self.tree_depth = 0

        if 'gen' in status:
            self.gen_age = status['gen']
        else:
            self.gen_age = {'type': 'D', 'age': 1}

        if 'restart_flag' in status:
            self.restart_flag = status['restart_flag']
        else:
            self.restart_flag = False

        if self.restart_flag:
            self.t_restart_off = status['t_restart_offset']
            self.next_ode = status['next_ode']
            self.scars = int(status['scars'])
            self.P0 = status['P0']
            if self.next_ode == 1:
                self.Ps, self.Rs, self.t1a, self.t1b, self.t2, self.tB, self.t_G1, self.t_G1_star, self.t_end = ([] for _ in range(9))
            else:
                self.Ps = [status['Ps']]
                self.Rs = []
                self.t1a, self.t1b, self.t2, self.tB, self.t_G1, self.t_G1_star, self.t_end = [status['t1a']], [status['t1b']], [status['t2']], [status['tB']], [status['t_G1']], [status['t_G1_star']], [status['t_end']]

        else:
            self.Ps, self.Rs, self.t1a, self.t1b, self.t2, self.tB, self.t_G1, self.t_G1_star, self.t_end = ([] for _ in range(9))
            self.t_restart_off = 0
            self.next_ode = 1
            self.scars = 0
            self.P0 = status['P']

    def generate_daughter(self, par, t_lim, stat_d0, id_d, tree, id_p, offset, cells):
        daughter = Cell(par, t_lim, stat_d0, id_d, tree, id_p, offset)
        daughter.cell_cycle(cells)
        cells.append(daughter)

    def growth(self, x, t):

        R, P, Cln3Far1, Far1, Cln3nuc = x

        if self.t1a_flag or (t <= self.t_G1[-1] / 60):
            if self.scars == 0:
                tau2 = self.par["tau2"]
            else:
                tau2 = self.par["tau2_s"]
            if self.scars <= 5:
                k2 = self.par["k2_list"][self.scars]
            else:
                k2 = self.par["k2_list"][6]
        else:
            k2 = self.par["k2_list"][0]
            tau2 = self.par["tau2"]

        v_cell = P / self.par["H"]
        v_nuc = self.par["h"] * v_cell
        cln3tot = self.par["theta"] * P
        cln3cyt = cln3tot - (Cln3nuc + Cln3Far1)
        eta_fun = self.par["eta"] * Cln3nuc ** self.par["nf"] / (Cln3nuc ** self.par["nf"] + Cln3Far1 ** self.par["nf"])

        dR = self.par["k1"] * max(0, self.par["rho"] * P - R) - R / self.par["tau1"]
        dP = k2 * R - P / tau2
        dCln3Far1 = (self.par["k_on"] / v_nuc) * Cln3nuc * Far1 - self.par["k_off"] * Cln3Far1
        dFar1 = -(self.par["k_on"] / v_nuc) * Cln3nuc * Far1 + self.par["k_off"] * Cln3Far1 - eta_fun * Far1
        dCln3nuc = - (self.par["k_on"] / v_nuc) * Cln3nuc * Far1 + self.par["k_off"] * Cln3Far1 + self.par["kcn"] * cln3cyt - self.par["knc"] * Cln3nuc
        return [dR, dP, dCln3Far1, dFar1, dCln3nuc]

    def growth_reset(self, x, t_ode3):

        R, P, Cln3Far1, Far1, Cln3nuc = x

        v_cell = P / self.par["H"]
        v_nuc_reset = self.par["h"] * v_cell / 2
        Cln3tot = self.par["theta"] * P
        Cln3cyt = Cln3tot - 2 * (Cln3nuc + Cln3Far1)

        dR = self.par["k1"] * max(0, self.par["rho"] * P - R) - R / self.par["tau1"]
        dP = self.par["k2_list"][0] * R - P / self.par["tau2"]
        dCln3Far1 = (self.par["k_on"] / v_nuc_reset) * Cln3nuc * Far1 - self.par["k_off"] * Cln3Far1
        dFar1 = -(self.par["k_on"] / v_nuc_reset) * Cln3nuc * Far1 + self.par["k_off"] * Cln3Far1
        dCln3nuc = - (self.par["k_on"] / v_nuc_reset) * Cln3nuc * Far1 + self.par["k_off"] * Cln3Far1 + self.par["kcn_reset"] * Cln3cyt - self.par["knc"] * Cln3nuc
        return [dR, dP, dCln3Far1, dFar1, dCln3nuc]

    def lognorm(self, mean, cv):
        rng = np.random.default_rng()
        sigma = mean * cv
        mu = np.log((mean * mean) / np.sqrt(mean * mean + sigma * sigma))
        sigma = np.sqrt(np.log(1 + (sigma * sigma) / (mean * mean)))
        return rng.lognormal(mu, sigma, 1)[0]

    def cell_cycle(self, cells):

        R_ode2, P_ode2, Cln3Far1_ode2, Far1_ode2, Cln3nuc_ode2, Cln3tot_ode2, Cln3cyt_ode2, t_ode2 = (np.array([]) for _ in range(8))
        x0_ode1 = self.x_start
        processes = []

        while self.t_offset[-1] <= self.t_lim:

            if self.next_ode == 1:

                t_ode1_start = 0
                t_ode1_end = 60
                self.t1a_flag = True

                while True:
                    t_ode1 = np.linspace(t_ode1_start, t_ode1_end, 61)
                    x = odeint(self.growth, x0_ode1, t_ode1 / 60 + self.t_restart_off)
                    R_ode1, P_ode1, Cln3Far1_ode1, Far1_ode1, Cln3nuc_ode1 = x.T
                    Cln3tot_ode1 = self.par["theta"] * P_ode1
                    Cln3cyt_ode1 = Cln3tot_ode1 - (Cln3nuc_ode1 + Cln3Far1_ode1)
                    self.t_cycle = np.concatenate((self.t_cycle, (t_ode1_start // 60) + self.t_offset[-1]), axis =None)
                    self.R_cycle = np.concatenate((self.R_cycle, R_ode1[0]), axis =None)
                    self.P_cycle = np.concatenate((self.P_cycle, P_ode1[0]), axis =None)
                    self.Cln3Far1_cycle = np.concatenate((self.Cln3Far1_cycle, Cln3Far1_ode1[0]), axis =None)
                    self.Far1_cycle = np.concatenate((self.Far1_cycle, Far1_ode1[0]), axis =None)
                    self.Cln3nuc_cycle = np.concatenate((self.Cln3nuc_cycle, Cln3nuc_ode1[0]), axis =None)
                    self.Cln3tot_cycle = np.concatenate((self.Cln3tot_cycle, Cln3tot_ode1[0]), axis =None)
                    self.Cln3cyt_cycle = np.concatenate((self.Cln3cyt_cycle, Cln3cyt_ode1[0]), axis =None)
                    self.bud.append(0)

                    if self.t_cycle[-1] == self.t_lim:
                        self.restart_status = {'P' : self.P_cycle[-1], 'R' : self.R_cycle[-1], 'Far1' : self.Far1_cycle[-1], 'Cln3Far1' : self.Cln3Far1_cycle[-1],
                                               'Cln3nuc' : self.Cln3nuc_cycle[-1], 'scars' : self.scars, 'next_ode': 1, 't_restart_offset': t_ode1[0],
                                               'P0': self.P0, 'type': self.gen_age['type'], 'age': self.gen_age['age']}

                    if np.any(Cln3nuc_ode1 > Cln3Far1_ode1):
                        self.t1a.append(t_ode1[np.where(Cln3nuc_ode1 > Cln3Far1_ode1)[0][0]] + self.t_restart_off)
                        break

                    else:
                        x0_ode1 = [R_ode1[-1], P_ode1[-1], Cln3Far1_ode1[-1], Far1_ode1[-1], Cln3nuc_ode1[-1]]
                        t_ode1_start += 60
                        t_ode1_end += 60

                self.t1a_flag = False

                t1b = max(self.par["t1b_min"], round((self.par["w0"] - self.par["w1"] * np.log(P_ode1[-1])) * 60, 0))
                t1b_rand = round(self.lognorm(t1b, self.par['cv_t1b']))
                self.t1b.append(t1b_rand)
                self.t2.append(round(self.lognorm(self.par["t2"], self.par['cv_t2'])))
                self.tB.append(round(self.lognorm(self.par["tB"], self.par['cv_tB'])))
                self.t_G1.append(self.t1a[-1] + self.t1b[-1] + self.t2[-1])
                self.t_G1_star.append(round(self.t_G1[-1] + self.tB[-1] * 8 / 10))
                self.t_end.append(self.t_G1[-1] + self.tB[-1])

                self.restart_flag = False
                self.next_ode = 2

            if self.next_ode == 2:

                if self.restart_flag:
                    x0_ode2 = self.x_start
                    t_ode2_start = self.t_restart_off
                else:
                    x0_ode2 = [R_ode1[-1], P_ode1[-1], Cln3Far1_ode1[-1], Far1_ode1[-1], Cln3nuc_ode1[-1]]
                    t_ode2_start = t_ode1[-1] + self.t_restart_off

                t_ode2 = np.arange(t_ode2_start, self.t_G1_star[-1], 1)
                x = odeint(self.growth, x0_ode2, t_ode2 / 60)

                R_ode2, P_ode2, Cln3Far1_ode2, Far1_ode2, Cln3nuc_ode2 = x.T
                Cln3tot_ode2 = self.par["theta"] * P_ode2
                Cln3cyt_ode2 = Cln3tot_ode2 - (Cln3nuc_ode2 + Cln3Far1_ode2)

                if not self.restart_flag:
                    G1_index = np.where(t_ode2 == self.t_G1[-1])[0][0]
                    Ps = P_ode2[G1_index]
                    if self.scars < 8:
                        cv_P = self.par['cv_P_list'][self.scars]
                    else:
                        cv_P = self.par['cv_P_list'][-1]
                    Ps_rand = self.lognorm(Ps, cv_P)
                    self.Ps.append(Ps_rand)

                t_ode2_abs = (t_ode2 - self.t_restart_off) / 60 + self.t_offset[-1]
                if self.t_lim in t_ode2_abs:
                    t_lim_index = np.where(t_ode2_abs == self.t_lim)[0][0]
                    self.restart_status = {'P' : P_ode2[t_lim_index], 'R' : R_ode2[t_lim_index], 'Far1' : Far1_ode2[t_lim_index], 'Cln3Far1' : Cln3Far1_ode2[t_lim_index],
                                           'Cln3nuc' : Cln3nuc_ode2[t_lim_index], 'scars' : self.scars, 'next_ode': 2, 't_restart_offset': t_ode2[t_lim_index], 'P0': self.P0,
                                           'type': self.gen_age['type'], 'age': self.gen_age['age'], 't1a': self.t1a[-1], 't1b': self.t1b[-1], 't2': self.t2[-1],
                                           'tB': self.tB[-1], 't_G1': self.t_G1[-1], 't_G1_star': self.t_G1_star[-1], 't_end': self.t_end[-1], 'Ps': self.Ps[-1]}

                self.restart_flag = False
                self.next_ode = 3

            if self.restart_flag:
                x0_ode3 = self.x_start
                t_ode3_start = self.t_restart_off
            else:
                x0_ode3 = [R_ode2[-1], P_ode2[-1], Cln3Far1_ode2[-1]/2, self.par["Far1_reset"], Cln3nuc_ode2[-1]/2]
                t_ode3_start = self.t_G1_star[-1]

            t_ode3 = np.arange(t_ode3_start, self.t_end[-1] + 1, 1)
            x = odeint(self.growth_reset, x0_ode3, t_ode3 / 60)

            R_ode3, P_ode3, Cln3Far1_ode3, Far1_ode3, Cln3nuc_ode3 = x.T
            Cln3tot_ode3 = self.par["theta"] * P_ode3
            Cln3cyt_ode3 = Cln3tot_ode3 - 2 * (Cln3nuc_ode3 + Cln3Far1_ode3)

            t_ode3_abs = (t_ode3 - self.t_restart_off) / 60 + self.t_offset[-1]
            if self.t_lim in t_ode3_abs:
                t_lim_index = np.where(t_ode3_abs == self.t_lim)[0][0]
                self.restart_status = {'P' : P_ode3[t_lim_index], 'R' : R_ode3[t_lim_index], 'Far1' : Far1_ode3[t_lim_index], 'Cln3Far1' : Cln3Far1_ode3[t_lim_index],
                                       'Cln3nuc' : Cln3nuc_ode3[t_lim_index], 'scars' : self.scars, 'next_ode': 3, 't_restart_offset': t_ode3[t_lim_index], 'P0': self.P0,
                                       'type': self.gen_age['type'], 'age': self.gen_age['age'], 't1a': self.t1a[-1], 't1b': self.t1b[-1], 't2': self.t2[-1],
                                       'tB': self.tB[-1], 't_G1': self.t_G1[-1], 't_G1_star': self.t_G1_star[-1], 't_end': self.t_end[-1], 'Ps': self.Ps[-1]}

            ix_ode3_int = np.where(t_ode3 %  60 == 0)
            t_rel = np.concatenate((t_ode2[::60], t_ode3[ix_ode3_int])) - self.t_restart_off
            self.bud += [0] * len(np.where(t_rel + self.t_restart_off < self.t_G1[-1])[0]) + [1] * len(np.where(t_rel + self.t_restart_off >= self.t_G1[-1])[0])
            self.t_cycle = np.concatenate((self.t_cycle, t_rel // 60 + self.t_offset[-1]), axis =None)
            self.R_cycle = np.concatenate((self.R_cycle, R_ode2[::60], R_ode3[ix_ode3_int]), axis =None)
            self.P_cycle = np.concatenate((self.P_cycle, P_ode2[::60], P_ode3[ix_ode3_int]), axis =None)
            self.Cln3Far1_cycle = np.concatenate((self.Cln3Far1_cycle, Cln3Far1_ode2[::60], Cln3Far1_ode3[ix_ode3_int]), axis =None)
            self.Far1_cycle = np.concatenate((self.Far1_cycle, Far1_ode2[::60], Far1_ode3[ix_ode3_int]), axis =None)
            self.Cln3nuc_cycle = np.concatenate((self.Cln3nuc_cycle, Cln3nuc_ode2[::60], Cln3nuc_ode3[ix_ode3_int]), axis =None)
            self.Cln3tot_cycle = np.concatenate((self.Cln3tot_cycle, Cln3tot_ode2[::60], Cln3tot_ode3[ix_ode3_int]), axis =None)
            self.Cln3cyt_cycle = np.concatenate((self.Cln3cyt_cycle, Cln3cyt_ode2[::60], Cln3cyt_ode3[ix_ode3_int]), axis =None)

            Rs_rand = self.R_cycle[-1] * self.Ps[-1] / self.P_cycle[-1]
            self.Rs.append(Rs_rand)

            self.t_offset.append(self.t_cycle[-1] + 1)
            self.t_restart_off = 0

            if self.t_offset[-1] <= self.t_lim:

                if self.gen_age['type'] == 'D':
                    gen_d = {'type': 'D', 'age': 1}
                    self.gen_age = {'type': 'P', 'age': 1}
                else:
                    gen_d = {'type': 'D', 'age': self.gen_age['age'] + 1}
                    self.gen_age = {'type': 'P', 'age': self.gen_age['age'] + 1}

                self.tree_depth += 1
                status_d0 = {'R' : (self.R_cycle[-1] - self.Rs[-1]), 'P' : (self.P_cycle[-1] - self.Ps[-1]), 'Cln3Far1' : self.Cln3Far1_cycle[-1], 'Far1' : self.Far1_cycle[-1],
                             'Cln3nuc' : self.Cln3nuc_cycle[-1], 'scars' : 0, 'next_ode': 1, 't_restart_offset' : 0, 'gen': gen_d, 'depth' : self.tree_depth}
                self.id_daughters.append(''.join(random.choices(string.ascii_lowercase + string.digits, k = 9)))
                if self.tree_depth > math.ceil(math.log(mp.cpu_count()/2, 2)):
                    self.generate_daughter(self.par, self.t_lim, status_d0, self.id_daughters[-1], self.tree_cell + 'd0', self.id_cell, self.t_offset[-1], cells)
                else:
                    p = mp.Process( target = self.generate_daughter, args = [self.par, self.t_lim, status_d0, self.id_daughters[-1], self.tree_cell + 'd0', self.id_cell, self.t_offset[-1], cells])
                    p.start()
                    processes.append(p)

                x0_ode1 = [self.Rs[-1], self.Ps[-1], self.Cln3Far1_cycle[-1], self.Far1_cycle[-1], self.Cln3nuc_cycle[-1]]
                self.restart_flag = False
                self.next_ode = 1
                self.P0 = self.Ps[-1]
                self.scars += 1
                self.tree_cell = self.tree_cell + 'p' + str(self.scars)
            print (f"Simulating {len(cells)} cells", end = '\r')

        for process in processes:
            process.join()

if __name__ == '__main__':

    red = '\033[31m'
    reset = '\033[0m'
    nutrients = {1: 'Glucose 0.05%', 2: 'Glucose 0.1%', 3: 'Glucose 0.2%', 4: 'Glucose 0.5%', 5: 'Glucose 2%', 6: 'Glucose 5%', 7: 'Ethanol 2%', 8: 'Custom'}
    cv_keys = ['cv_t2', 'cv_tB', 'cv_t1b', 'cv_P', 'cv_P_1', 'cv_P_2', 'cv_P_3', 'cv_P_4', 'cv_P_5', 'cv_P_6', 'cv_P_7', 'cv_P_s']
    while True:
            par_select = input('\nSelect the set of parameters:\n1. Default Glucose 0.05%\n2. Default Glucose 0.1%\n3. Default Glucose 0.2%\n4. Default Glucose 0.5%\n5. Default Glucose 2%\n6. Default Glucose 5%\n7. Default Ethanol 2%\n8. Custom\n')
            try:
                if float(par_select).is_integer():
                    par_select = int(par_select)
                    if par_select in range(1, 9):
                        if par_select == 8:
                            os.startfile(r'.\config\parameters.xlsx')
                            input('After saving the custom parameters, press Enter to continue.')
                        try:
                            param_set = pd.read_excel(r'.\config\parameters.xlsx', index_col = 'Nutrient').loc[nutrients[par_select]].to_dict()
                            for key in ['t2', 'tB', 't1b_min']:
                                param_set[key] = int(param_set[key] * 60)
                            param_set['k2_list'] = [param_set['k2'], param_set['k2_1'], param_set['k2_2'], param_set['k2_3'], param_set['k2_4'], param_set['k2_5'], param_set['k2_s']]
                            if any(np.isnan(value) for value in {cv_key: param_set[cv_key] for cv_key in cv_keys}.values()):
                                param_set['cv_t2'], param_set['cv_tB'], param_set['cv_t1b'] = [0.05, 0.05, 0.05]
                                param_set['cv_P_list'] = [0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.04, 0.03, 0.02]
                            else:
                                param_set['cv_P_list'] = [param_set['cv_P'], param_set['cv_P_1'], param_set['cv_P_2'], param_set['cv_P_3'], param_set['cv_P_4'], param_set['cv_P_5'], param_set['cv_P_6'], param_set['cv_P_7'], param_set['cv_P_s']]
                            drop = ['k2', 'k2_1', 'k2_2', 'k2_3', 'k2_4', 'k2_5', 'k2_s', 'cv_P', 'cv_P_1', 'cv_P_2', 'cv_P_3', 'cv_P_4', 'cv_P_5', 'cv_P_6', 'cv_P_7', 'cv_P_s']
                            for key in drop:
                                param_set.pop(key, None)
                            break
                        except:
                            print(f'{red}\nCustom parameters not available.{reset}')
                    else:
                        raise ValueError
                else:
                    raise ValueError
            except ValueError:
                print(f"{red}\nInvalid selection.{reset}")

    start_defaults = {1: {'P': 1.46e10, 'Far1': 170}, 2: {'P': 2.10e10, 'Far1': 240}, 3: {'P': 1.99e10, 'Far1': 240}, 4: {'P': 2.54e10, 'Far1': 240}, 5: {'P': 3.03e10, 'Far1': 240}, 6: {'P': 3.76e10, 'Far1': 240}, 7: {'P': 1.46e10, 'Far1': 110}}
    while True:
        start_select = input('\nSelect the initial conditions:\n1. Default Glucose 0.05%\n2. Default Glucose 0.1%\n3. Default Glucose 0.2%\n4. Default Glucose 0.5%\n5. Default Glucose 2%\n6. Default Glucose 5%\n7. Default Ethanol 2%\n8. Custom\n')
        try:
            if float(start_select).is_integer():
                start_select = int(start_select)
                if start_select in range(1, 8):
                    start_status = [{'R': start_defaults[start_select]['P'] * param_set['rho'], 'P': start_defaults[start_select]['P'], 'Far1': start_defaults[start_select]['Far1'], 'Cln3Far1': 1, 'Cln3nuc': 1}]
                    break
                elif start_select == 8:
                    root = tk.Tk()
                    root.withdraw()
                    root.wm_attributes('-topmost', 1)
                    currentdir = os.getcwd()
                    start_path = filedialog.askopenfilename(parent = root, title = "Seleziona il file contenente le condizioni iniziali", initialdir = currentdir)
                    root.destroy()
                    start_status = pd.read_csv(start_path).to_dict('records')
                    for status in start_status:
                        if 'Cln3Far1' not in status:
                            status['Cln3Far1'] = 1
                        if 'Cln3nuc' not in status:
                            status['Cln3nuc'] = 1
                    restart_features = ['scars', 'next_ode', 't_restart_offset', 'P0', 'type', 'age', 't1a', 't1b', 't2', 'tB', 't_G1', 't_G1_star', 't_end', 'Ps']
                    for status in start_status:
                        if all(feature in status for feature in restart_features) and not all(np.isnan(value) for value in {feature: status[feature] for feature in restart_features}.values()):
                            status['restart_flag'] = True
                            status['gen'] = {'type': status['type'], 'age': status['age']}
                            for key in ['type', 'age']:
                                status.pop(key, None)
                            if status['next_ode'] == 1:
                                for key in ['t1a', 't1b', 't2', 'tB', 't_G1', 't_G1_star', 't_end','Ps']:
                                    status.pop(key, None)
                        else:
                            status['restart_flag'] = False
                            for key in restart_features:
                                status.pop(key, None)
                    break
                else:
                    raise ValueError
        except ValueError:
            print(f"{red}\nInvalid selection.{reset}")

    t_end_estimate = {1: 133, 2: 122, 3: 113, 4: 105, 5: 99, 6: 98, 7: 199}
    t_confirm = 2
    while t_confirm == 2:
        while True:
            t_lim_in = input('\nInsert the desired lifespan for the population (min):\n')
            try:
                t_lim = int(float(t_lim_in))
                if t_lim < 1:
                    raise ValueError
                break
            except ValueError:
                print(f"{red}\nInvalid selection.{reset}")
        if par_select == 8:
            t_confirm = 1
        else:
            n_cycles_estimate = t_lim / t_end_estimate[par_select]
            n_cells_estimate = 2 ** (n_cycles_estimate - 0.5)
            magnitude = math.floor(math.log10(abs(n_cells_estimate)))
            highest_place = 10 ** magnitude
            n_cells_estimate_round = max(1, round(n_cells_estimate / highest_place) * highest_place)
            while True:
                t_confirm = input(f'\nApproximately {n_cells_estimate_round} cells will be simulated:\n1. Start the simulation\n2. Re-enter the desired lifespan\n')
                try:
                    t_confirm = int(float(t_confirm))
                    if t_confirm not in [1, 2]:
                        raise ValueError
                    break
                except ValueError:
                    print(f"{red}\nInvalid selection.{reset}")
    print('\n')

    with mp.Manager() as manager:

        cells = manager.list()

        for i in range(len(start_status)):
            tree_c = f"cl{i}_d0"
            id_c = ''.join(random.choices(string.ascii_lowercase + string.digits, k = 9))
            daughter = Cell(param_set, t_lim, start_status[i], id_c, tree_c, None, 0)
            daughter.cell_cycle(cells)
            cells.append(daughter)

        print (f"\nFinished simulating {len(cells)} cells in {datetime.now() - startTime} \nWait for the outputs...", end = '\n')

        output_path = fr'.\Output_{datetime.now().strftime("%Y%m%d-%H%M%S")}'
        os.mkdir(output_path)
        os.mkdir(fr'{output_path}\Graphs')
        os.mkdir(fr'{output_path}\Raw_data')

        P_all, R_all, buds_all = {}, {}, {}
        pt_daughters, pt_parents, rt_daughters, rt_parents, restart_status, t1a, t1b, t2, tB, Ps, Rs, P0, c_type, age = ([] for _ in range(14))
        for cell in cells:
            P_all[cell.id_cell] = pd.Series(cell.P_cycle, index = cell.t_cycle)
            R_all[cell.id_cell] = pd.Series(cell.R_cycle, index = cell.t_cycle)
            buds_all[cell.id_cell] = pd.Series(cell.bud, index = cell.t_cycle)
            restart_status.append(cell.restart_status)
            (pt_parents if cell.gen_age['type'] == 'P' else pt_daughters).append(cell.restart_status['P'])
            (rt_parents if cell.gen_age['type'] == 'P' else rt_daughters).append(cell.restart_status['R'])
            t1a.append(cell.t1a[-1] / 60)
            t1b.append(cell.t1b[-1] / 60)
            t2.append(cell.t2[-1] / 60)
            tB.append(cell.tB[-1] / 60)
            Ps.append(cell.Ps[-1])
            Rs.append(cell.Rs[-1])
            P0.append(cell.P0)
            c_type.append(cell.gen_age['type'])
            age.append(cell.gen_age['age'])

        restart_status = pd.DataFrame(restart_status)
        restart_status.to_csv(fr'{output_path}\Raw_data\Restart_conditions.csv', index = False)

        P_all = pd.DataFrame(P_all)
        R_all = pd.DataFrame(R_all)
        buds_all = pd.DataFrame(buds_all)
        P_mean = P_all.mean(axis = 1)
        R_mean = R_all.mean(axis = 1)
        bud_fract = buds_all.mean(axis = 1)
        P_all.index.name = 't'
        R_all.index.name = 't'
        buds_all.index.name = 't'
        N_cells = P_all.count(axis = 'columns')

        ratio = pd.DataFrame({'P_mean': P_mean, 'R_mean': R_mean, 'bud_fract' : bud_fract, 'n_cells': N_cells}).iloc[: t_lim + 1]
        ratio.to_csv(fr'{output_path}\Raw_data\Time_ev.csv')

        pt_all = pt_daughters + pt_parents
        rt_all = rt_daughters + rt_parents
        np.savetxt(fr'{output_path}\Raw_data\P_distro.csv', pt_all)
        np.savetxt(fr'{output_path}\Raw_data\R_distro.csv', rt_all)
        np.savetxt(fr'{output_path}\Raw_data\P_distro_daughters.csv', pt_daughters)
        np.savetxt(fr'{output_path}\Raw_data\R_distro_daughters.csv', rt_daughters)
        np.savetxt(fr'{output_path}\Raw_data\P_distro_parents.csv', pt_parents)
        np.savetxt(fr'{output_path}\Raw_data\R_distro_parents.csv', rt_parents)

        df = pd.DataFrame({'t1a': t1a, 't1b': t1b, 't2': t2, 'tB': tB, 'Ps': Ps, 'Rs': Rs, 'P0': P0, 'type': c_type, 'age': age})
        P_ages = sorted(df[df['type'] == 'P']['age'].unique())
        D_ages = sorted(df[df['type'] == 'D']['age'].unique())

        keys = ['P0', 'Ps', 'Rs', 't1a', 't1b', 't2', 'tB']
        cols = ['P0_mean', 'P0_std', 'Ps_mean', 'Ps_std', 'Rs_mean', 'Rs_std', 't1a_mean', 't1a_std', 't1b_mean', 't1b_std', 't2_mean', 't2_std', 'tB_mean', 'tB_std']
        stats_all, stats_d, stats_p = (pd.DataFrame(columns = ['CELL'] + cols, index = [' ']) for _ in range(3))
        stats_all.index.name = 'TOTALE'
        stats_p.index.name = 'TOTALE'
        stats_d.index.name = 'TOTALE'
        stats_all['CELL'] = [len(cells)]
        stats_d['CELL'] = [len(pt_daughters)]
        stats_p['CELL'] = [len(pt_parents)]
        stats_p_by_age = pd.DataFrame(columns = ['CELL'] + cols,  index = P_ages)
        stats_p_by_age.index.name = 'AGE'
        stats_d_by_age = pd.DataFrame(columns = ['CELL'] + cols,  index = D_ages)
        stats_d_by_age.index.name = 'AGE'

        for key in keys:
            stats_all[key + '_mean'] = [df[key].mean()]
            stats_all[key + '_std'] = [df[key].std()]
            stats_d[key + '_mean'] =  [df[df['type'] == 'D'][key].mean()]
            stats_d[key + '_std'] =  [df[df['type'] == 'D'][key].std()]
            stats_p[key + '_mean'] =  [df[df['type'] == 'P'][key].mean()]
            stats_p[key + '_std'] =  [df[df['type'] == 'P'][key].std()]

        for P_age in P_ages:
            for key in keys:
                stats_p_by_age.loc[P_age, key + '_mean'] = df[(df['type'] == 'P') & (df['age'] == P_age)][key].mean()
                stats_p_by_age.loc[P_age, key + '_std'] = df[(df['type'] == 'P') & (df['age'] == P_age)][key].std()
                stats_p_by_age.loc[P_age, 'CELL'] = df[(df['type'] == 'P') & (df['age'] == P_age)].shape[0]
        for D_age in D_ages:
            for key in keys:
                stats_d_by_age.loc[D_age, key + '_mean'] = df[(df['type'] == 'D') & (df['age'] == D_age)][key].mean()
                stats_d_by_age.loc[D_age, key + '_std'] = df[(df['type'] == 'D') & (df['age'] == D_age)][key].std()
                stats_d_by_age.loc[D_age, 'CELL'] = df[(df['type'] == 'D') & (df['age'] == D_age)].shape[0]

        with open(fr'{output_path}\Raw_data\Statistics.csv','a', newline = '') as f:
            stats_all.reset_index().to_csv(f, index = False)
            f.write('\nPARENTS\n\n')
            stats_p.reset_index().to_csv(f, index = False)
            f.write('\n')
            stats_p_by_age.infer_objects(copy = False).fillna(0).reset_index().to_csv(f, index = False)
            f.write('\nDAUGHTERS\n\n')
            stats_d.reset_index().to_csv(f, index = False)
            f.write('\n')
            stats_d_by_age.infer_objects(copy = False).fillna(0).reset_index().to_csv(f, index = False)

        fig1, ax1 = plt.subplots()
        fig2, ax2 = plt.subplots()
        fig3, ax3 = plt.subplots()
        fig4, ax4 = plt.subplots()
        fig5, ax5 = plt.subplots()
        fig6, ax6 = plt.subplots()
        y_pd, _, _ = ax1.hist(pt_daughters, 100, edgecolor = 'black')
        y_rd, _, _ = ax2.hist(rt_daughters, 100, edgecolor = 'black')
        y_pp, _, _ = ax3.hist(pt_parents, 100, edgecolor = 'black')
        y_rp, _, _ = ax4.hist(rt_parents, 100, edgecolor = 'black')
        y_p, _, _ = ax5.hist(pt_all, 100, edgecolor = 'black')
        y_r, _, _ = ax6.hist(rt_all, 100, edgecolor = 'black')
        y_max = max(chain(y_pd, y_rd, y_pp, y_rp, y_p, y_r))
        x_max_p = max(pt_all)
        x_max_r = max(rt_all)

        ax1.set_xlabel('Protein Content (#aa)')
        ax1.set_ylabel('Number of daughters')
        ax1.set_xlim(left = 0, right = x_max_p*1.05)
        ax1.set_ylim(top = y_max*1.05)
        fig1.savefig(fr'{output_path}\Graphs\P_distro_daughters.jpg', dpi = 240)

        ax2.set_xlabel('Number of Ribosomes')
        ax2.set_ylabel('Number of daughters')
        ax2.set_xlim(left = 0, right = x_max_r*1.05)
        ax2.set_ylim(top = y_max*1.05)
        fig2.savefig(fr'{output_path}\Graphs\R_distro_daughters.jpg', dpi = 240)

        ax3.set_xlabel('Protein Content (#aa)')
        ax3.set_ylabel('Number of parents')
        ax3.set_xlim(left = 0, right = x_max_p*1.05)
        ax3.set_ylim(top = y_max*1.05)
        fig3.savefig(fr'{output_path}\Graphs\P_distro_parents.jpg', dpi = 240)

        ax4.set_xlabel('Number of Ribosomes')
        ax4.set_ylabel('Number of parents')
        ax4.set_xlim(left = 0, right = x_max_r*1.05)
        ax4.set_ylim(top = y_max*1.05)
        fig4.savefig(fr'{output_path}\Graphs\R_distro_parents.jpg', dpi = 240)

        ax5.set_xlabel('Protein Content (#aa)')
        ax5.set_ylabel('Number of cells')
        ax5.set_xlim(left = 0, right = x_max_p*1.05)
        ax5.set_ylim(top = y_max*1.05)
        fig5.savefig(fr'{output_path}\Graphs\P_distro.jpg', dpi = 240)

        ax6.set_xlabel('Number of Ribosomes')
        ax6.set_ylabel('Number of cells')
        ax6.set_xlim(left = 0, right = x_max_r*1.05)
        ax6.set_ylim(top = y_max*1.05)
        fig6.savefig(fr'{output_path}\Graphs\R_distro.jpg', dpi = 240)

        cols = ['P0_mean', 'Ps_mean', 't1a_mean', 't1b_mean']
        cols_std = ['P0_std', 'Ps_std', 't1a_std', 't1b_std']
        fig7, ax7 = plt.subplots(nrows=1, ncols=4, figsize=(16, 4))
        fig8, ax8 = plt.subplots(nrows=1, ncols=4, figsize=(16, 4))
        fig9, ax9 = plt.subplots(nrows=1, ncols=4, figsize=(16, 4))
        ymax = {}

        for i in range(len(cols)):
            data_mean_all = stats_all.iloc[0, stats_all.columns.get_loc(cols[i])]
            err_all = stats_all.iloc[0, stats_all.columns.get_loc(cols_std[i])]
            rects_all = ax7[i].bar(1, data_mean_all, 0.5, yerr = err_all, error_kw = {'capsize': 5})

            data_mean_d = stats_d.iloc[0, stats_d.columns.get_loc(cols[i])]
            err_d = stats_d.iloc[0, stats_d.columns.get_loc(cols_std[i])]
            rects_d = ax8[i].bar(1, data_mean_d, 0.5, yerr = err_d, error_kw = {'capsize': 5})

            data_mean_p = stats_p.iloc[0, stats_p.columns.get_loc(cols[i])]
            err_p = stats_p.iloc[0, stats_p.columns.get_loc(cols_std[i])]
            rects_p = ax9[i].bar(1, data_mean_p, 0.5, yerr = err_p, error_kw = {'capsize': 5})

            ymax[i] = max(data_mean_all + err_all, data_mean_d + err_d, data_mean_p + err_p)

        for i in range (2):
            ax7[i].set_ylabel('Proteins (#aa)')
            ax8[i].set_ylabel('Proteins (#aa)')
            ax9[i].set_ylabel('Proteins (#aa)')
        for i in range(2, 4):
            ax7[i].set_ylabel('Time (min)')
            ax8[i].set_ylabel('Time (min)')
            ax9[i].set_ylabel('Time (min)')
        for i in range(4):
            ax7[i].set_xticks([1], [cols[i]])
            ax7[i].set_xlim(left = 0.5, right = 1.5)
            ax7[i].set_ylim(top = ymax[i]*1.1)
            ax8[i].set_xticks([1], [cols[i]])
            ax8[i].set_xlim(left = 0.5, right = 1.5)
            ax8[i].set_ylim(top = ymax[i]*1.1)
            ax9[i].set_xticks([1], [cols[i]])
            ax9[i].set_xlim(left = 0.5, right = 1.5)
            ax9[i].set_ylim(top = ymax[i]*1.1)

        fig7.suptitle("All Cells", fontsize=14)
        fig7.savefig(fr'{output_path}\Graphs\Statistics.jpg', dpi = 240)
        fig8.suptitle("Daughter Cells", fontsize=14)
        fig8.savefig(fr'{output_path}\Graphs\Statistics_daughters.jpg', dpi = 240)
        fig9.suptitle("Parent Cells", fontsize=14)
        fig9.savefig(fr'{output_path}\Graphs\Statistics_parents.jpg', dpi = 240)

        fig10, ax10 = plt.subplots()
        ax10.plot(ratio.index, ratio['R_mean'], '-', color='k')
        ax10.set_xlabel('t (min)')
        ax10.set_ylabel('Average Ribosome content')

        fig11, ax11 = plt.subplots()
        ax11.plot(ratio.index, ratio['P_mean'], '-', color='k')
        ax11.set_xlabel('t (min)')
        ax11.set_ylabel('Average Protein content (#aa)')

        fig12, ax12 = plt.subplots()
        ax12.plot(ratio.index, ratio['bud_fract'], '-', color='k')
        ax12.set_xlabel('t (min)')
        ax12.set_ylabel('Budded fraction')

        fig13, ax13 = plt.subplots()
        ax13.plot(ratio.index, ratio['n_cells'], '-', color='k')
        ax13.set_xlabel('t (min)')
        ax13.set_ylabel('Number of cells')
        ax13.set_xlim(left = 0)

        fig14, ax14 = plt.subplots()
        ax14.plot(ratio.index, ratio['n_cells'], '-', color='k')
        ax14.set_xlabel('t (min)')
        ax14.set_ylabel('Number of cells (log)')
        ax14.set_xlim(left = 0)
        ax14.set_yscale('log')

        fig10.savefig(fr'{output_path}\Graphs\Time_Ev_R_mean.jpg', dpi = 240)
        fig11.savefig(fr'{output_path}\Graphs\Time_Ev_P_mean.jpg', dpi = 240)
        fig12.savefig(fr'{output_path}\Graphs\Time_Ev_Bud_fraction.jpg', dpi = 240)
        fig13.savefig(fr'{output_path}\Graphs\Time_Ev_N_cells.jpg', dpi = 240)
        fig14.savefig(fr'{output_path}\Graphs\Time_Ev_N_cells_log.jpg', dpi = 240)

        plt.close('all')

    print(f"\nCompleted everything in: {datetime.now() - startTime}\n")
