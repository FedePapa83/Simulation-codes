function dx = GCMfun_reset(t,x)

    global K1 D1 rho K2 D2 Kon Koff Kcnreset Knc teta H h;
        
    P           = x(1);
    R           = x(2);
    Cln3        = x(3);
    Far1        = x(4);
    Cln3Far1    = x(5);

    Cln3_tot    = teta*P;
    Cln3_cyt    = Cln3_tot - 2*(Cln3 + Cln3Far1);
    V           = 0.5*h*P/H;

    k2 = K2(1);
    d2 = D2(1);

    dP          = k2*R - P/d2;
    dR          = K1*max(rho*P - R,0) - R/D1;
    dCln3       = -Kon*Cln3*Far1/V + Koff*Cln3Far1 + Kcnreset*Cln3_cyt - Knc*Cln3;
    dFar1       = -Kon*Cln3*Far1/V + Koff*Cln3Far1;
    dCln3Far1   = Kon*Cln3*Far1/V - Koff*Cln3Far1;

    dx          = [dP; dR; dCln3; dFar1; dCln3Far1];
    
end