clc
clear
close all

global TotNumCell_Exp TotNumBin P_mix
global Bin Numbers_Exp;


%% Description

%This code compares the protein distribution of a yeast population simulated in Python (code stored in iMeGroCy/GroCy)
%with the experimental one, in the same nutrient condition.  
%The program performs the estimation of the lower value and bin size of the protein scale of the two distributions
%by implementing the procedure described in the subsection "Comparisons of experimental and simulated distributions" of the "Method" section, in the main text.
%The two distributions are then plotted in the same figure for a direct comparison.
%The experimental data ("Data.mat") and the simulation (subfolder "Output"), given as an example, refer to glucose 2% 
%and they are stored in the folders "ExpData" and, respectively, "SimData". 
%Replace the default files with your own data/simulation, using the same notation for the file names.


%% Loading the experimental protein content 

load(['ExpData/Data.mat']);              %"Numbers_Exp" is the vector of the number of cells over 1024 bins

TotNumCell_Exp = sum(Numbers_Exp);       %Total number of cells in the experimental population
TotNumBin      = length(Numbers_Exp);    %Total number of bins 
Bin            = (1:1:TotNumBin);        %Bin vector

%% Loading the simulated protein content 

P     = csvread(['SimData/Output/Raw_data/P_distro.csv']);
P_mix = P(randperm(length(P)));          %Shuffle of the simulated protein content

%% Experimental vs Simulated comparison 

%Estimated values of the lower value and bin size of the protein scale 
%on the basis of the experimental protein distribution

%fminsearch setting
MYOPT       = optimset('fminsearch');
MYOPT       = optimset(MYOPT,'MaxFunEvals',20000,'MaxIter',500, 'TolFun',1.e-10,'TolX',1.e-10, 'Diagnostics','on','Display','iter','LargeScale','off','HessUpdate','bfgs');

%Initial conditions
Pmin_0     = 1; %min(P_mix);                      %Initial lower value of the P-scale
alfa_0     = log(Pmin_0);
Pmax_0     = 7e10; %max(P_mix);                   %Initial higher value of the P-scale
Pstep_0    = ((Pmax_0 - Pmin_0)/(TotNumBin-1));   %Initial bin size

[par, f]	= fminsearch(@Loss_fun, [alfa_0 Pstep_0] , MYOPT);
%[par, f]	= fminsearch(@Loss_fun, [Pmin_0 Pstep_0] , MYOPT);

Pmin    = exp(par(1))
%Pmin    = par(1)
Pstep   = par(2)
Pmax    = Pmin + (TotNumBin-1)*Pstep;

Popt = P_mix(find(P_mix<Pmax));                %Cutting of the outliers
Popt = Popt(1:TotNumCell_Exp);                 %Extraction of a sample of the same size of the experimental one

[Nbin,Pbin]   = hist(Popt,[Pmin:Pstep:Pmax]); %Pbin: mean protein content of each bin; Nbin: number of cells in each bin


%% Moving window average (over 13 points)

%Experimental
Numbers_Exp_Av13 = zeros(size(Numbers_Exp));

for i=1:length(Numbers_Exp)
    if i<7
        Numbers_Exp_Av13(i) = mean(Numbers_Exp(1:i+6));
    elseif i>length(Numbers_Exp)-6
        Numbers_Exp_Av13(i) = mean(Numbers_Exp(i-6:length(Numbers_Exp)));
    else
        Numbers_Exp_Av13(i) = mean(Numbers_Exp(i-6:i+6));
    end
end

%Simulated
Numbers_Sim_Av13  = zeros(size(Nbin));

for i=1:length(Nbin)
    if i<7
        Numbers_Sim_Av13(i)  = mean(Nbin(1:i+6));
    elseif i>length(Nbin)-6
        Numbers_Sim_Av13(i)  = mean(Nbin(i-6:length(Nbin)));
    else
        Numbers_Sim_Av13(i)  = mean(Nbin(i-6:i+6));
    end
end


%% Figure

fig = figure('PaperSize',[20.98 29.68]);
plot(Pbin,Numbers_Exp_Av13,'r',Pbin,Numbers_Sim_Av13,'b','LineWidth',3), hold on; % ylim([0 max([max(Numbers_Exp_Av13) max(Numbers_sim_Av13)])]), 
g   = legend('Experimental', 'Simulated');
set(g, 'FontSize', 24, 'FontWeight','normal', 'Location', 'NorthEast');
set(gca,'FontSize',24);

xlabel('Protein content (aa)', 'FontSize',30);
ylabel('Number of cells', 'FontSize',30);
