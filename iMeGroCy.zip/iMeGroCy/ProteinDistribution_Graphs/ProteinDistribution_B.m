clc
clear
close all

global TotNumCell_Exp TotNumBin P_mix
global Bin Numbers_Exp;


%% Description

%This code the protein distributions of the Python simulations (code stored in iMeGroCy/GroCy) with the corresponding experimental ones, for two different nutrient conditions: glucose 2% and 0.05%. 
%The program has two sections: 
%(i) fitting section, related to glucose 2% - the program performs the estimation of the lower value and bin size of the protein scale of the experimental-vs-simulated distribution, 
%implementing the procedure described in the subsection "Comparisons of experimental and simulated distributions" of the "Method" section of the main text; 
%the resulting experimental and simulated distributions are then plotted in the same figure for a direct comparison.
%(ii) prediction section, related to glucose 0.05% - the programs directly plots the experimental and simulated distributions, exploiting the protein scale estimated in section (i).
%The experimental data ("Data_CENPK_2glc.mat" and "Data_CENPK_0p05glc.mat") and the simulations (subfolders "Output_2glc" and "Output_0p05glc")
%are reported in the folders "ExpData" and, respectively, "SimData".


%% Section (i): fitting of the experimental distribution of glucose 2% 

% Loading the experimental protein content 

load('ExpData/Data_CENPK_2glc.mat');     %"Numbers_Exp" is the vector of the number of cells over 1024 bins

TotNumCell_Exp = sum(Numbers_Exp);       %Total number of cells in the experimental population
TotNumBin      = length(Numbers_Exp);    %Total number of bins 
Bin            = (1:1:TotNumBin);        %Bin vector

% Loading the simulated protein content 

P     = csvread('SimData/Output_2glc/Raw_data/P_distro.csv');
P_mix = P(randperm(length(P)));          %Shuffle of the simulated protein content

% Experimental vs Simulated comparison 

%Estimation of the lower value and bin size of the protein scale on
%the basis of the experimental protein distribution of CENPK 2% glucose

%fminsearch setting
MYOPT       = optimset('fminsearch');
MYOPT       = optimset(MYOPT,'MaxFunEvals',20000,'MaxIter',500, 'TolFun',1.e-10,'TolX',1.e-10, 'Diagnostics','on','Display','iter','LargeScale','off','HessUpdate','bfgs');

%Initial conditions
Pmin_0     = 1; %min(P_mix);                      %Initial lower value of the P-scale
alfa_0     = log(Pmin_0);
Pmax_0     = 7e10; %max(P_mix);                   %Initial higher value of the P-scale
Pstep_0    = ((Pmax_0 - Pmin_0)/(TotNumBin-1));   %Initial bin size

[par, f]	= fminsearch(@Loss_fun, [alfa_0 Pstep_0] , MYOPT);
%[par, f]	= fminsearch(@Loss_fun, [Pmin_0 Pstep_0] , MYOPT);

Pmin    = exp(par(1))
%Pmin    = par(1)
Pstep   = par(2)
Pmax    = Pmin + (TotNumBin-1)*Pstep;

Popt = P_mix(find(P_mix<Pmax));                %Cutting of the outliers
Popt = Popt(1:TotNumCell_Exp);                 %Extraction of a sample of the same size of the experimental one

[Nbin,Pbin]   = hist(Popt,[Pmin:Pstep:Pmax]); %Pbin: mean protein content of each bin; Nbin: number of cells in each bin


%% Moving window average (over 13 points)

%Experimental
Numbers_Exp_Av13 = zeros(size(Numbers_Exp));

for i=1:length(Numbers_Exp)
    if i<7
        Numbers_Exp_Av13(i) = mean(Numbers_Exp(1:i+6));
    elseif i>length(Numbers_Exp)-6
        Numbers_Exp_Av13(i) = mean(Numbers_Exp(i-6:length(Numbers_Exp)));
    else
        Numbers_Exp_Av13(i) = mean(Numbers_Exp(i-6:i+6));
    end
end

%Simulated
Numbers_Sim_Av13  = zeros(size(Nbin));

for i=1:length(Nbin)
    if i<7
        Numbers_Sim_Av13(i)  = mean(Nbin(1:i+6));
    elseif i>length(Nbin)-6
        Numbers_Sim_Av13(i)  = mean(Nbin(i-6:length(Nbin)));
    else
        Numbers_Sim_Av13(i)  = mean(Nbin(i-6:i+6));
    end
end


% Figure

fig = figure('PaperSize',[20.98 29.68]);
plot(Pbin,Numbers_Exp_Av13,'r',Pbin,Numbers_Sim_Av13,'b','LineWidth',3), hold on; % ylim([0 max([max(Numbers_Exp_Av13) max(Numbers_sim_Av13)])]), 
g   = legend(' 2% glucose: Experimental', ' 2% glucose: Simulated');
set(g, 'FontSize', 24, 'FontWeight','normal', 'Location', 'NorthEast');
set(gca,'FontSize',24);

xlabel('Protein content (aa)', 'FontSize',30);
ylabel('Number of cells', 'FontSize',30);


%% Section (ii): prediction of the experimental distribution of glucose 0.05% 

% Loading the experimental protein content 

load('ExpData/Data_CENPK_0p05glc.mat');     %"Numbers_Exp" is the vector of the number of cells over 1024 bins

TotNumCell_Exp = sum(Numbers_Exp);       %Total number of cells in the experimental population
TotNumBin      = length(Numbers_Exp);    %Total number of bins 
Bin            = (1:1:TotNumBin);        %Bin vector

% Loading the simulated protein content 

P     = csvread('SimData/Output_0p05glc/Raw_data/P_distro.csv');
P_mix = P(randperm(length(P)));          %Shuffle of the simulated protein content

% Experimental vs Simulated comparison 

Popt = P_mix(find(P_mix<Pmax));                %Cutting of the outliers
Popt = Popt(1:TotNumCell_Exp);                 %Extraction of a sample of the same size of the experimental one

[Nbin,Pbin]   = hist(Popt,[Pmin:Pstep:Pmax]); %Pbin: mean protein content of each bin; Nbin: number of cells in each bin


%% Moving window average (over 13 points)

%Experimental
Numbers_Exp_Av13 = zeros(size(Numbers_Exp));

for i=1:length(Numbers_Exp)
    if i<7
        Numbers_Exp_Av13(i) = mean(Numbers_Exp(1:i+6));
    elseif i>length(Numbers_Exp)-6
        Numbers_Exp_Av13(i) = mean(Numbers_Exp(i-6:length(Numbers_Exp)));
    else
        Numbers_Exp_Av13(i) = mean(Numbers_Exp(i-6:i+6));
    end
end

%Simulated
Numbers_Sim_Av13  = zeros(size(Nbin));

for i=1:length(Nbin)
    if i<7
        Numbers_Sim_Av13(i)  = mean(Nbin(1:i+6));
    elseif i>length(Nbin)-6
        Numbers_Sim_Av13(i)  = mean(Nbin(i-6:length(Nbin)));
    else
        Numbers_Sim_Av13(i)  = mean(Nbin(i-6:i+6));
    end
end


% Figure

fig2 = figure('PaperSize',[20.98 29.68]);
plot(Pbin,Numbers_Exp_Av13,'r',Pbin,Numbers_Sim_Av13,'b','LineWidth',3), hold on; % ylim([0 max([max(Numbers_Exp_Av13) max(Numbers_sim_Av13)])]), 
g   = legend(' 0.05% glucose: Experimental', ' 0.05% glucose: Simulated');
set(g, 'FontSize', 24, 'FontWeight','normal', 'Location', 'NorthEast');
set(gca,'FontSize',24);

xlabel('Protein content (aa)', 'FontSize',30);
ylabel('Number of cells', 'FontSize',30);
