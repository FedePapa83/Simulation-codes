clc
clear all
close all

rho     = 2.05e-5;
tau2    = 3000;
K2      = 367.69;
lambda  = rho*K2-1/tau2;

tau2    = [600 1500 3000 6000 15000];
K2      = (lambda*tau2 + 1)/rho./tau2;

tau2_cont   = 10:1:3.5e4;
K2_cont     = (lambda*tau2_cont + 1)/rho./tau2_cont;

figure
plot(K2_cont,tau2_cont),axis([350 550 0 3e4]),hold on
plot(K2,tau2,'d'),xlabel('K_2 (aa/rib/min)'),ylabel('\tau_2(min)')