function Loss = Loss_fun(theta)


global Numbers_Exp TotNumCell_Exp TotNumBin P_mix

Pmin   = exp(theta(1));                    %Lower value of the P-scale
%Pmin = theta(1);                           %Lower value of the P-scale
Pstep  = theta(2);                         %Bin size
Pmax   = Pmin + (TotNumBin-1)*Pstep;       %Higher value of the P-scale

P = P_mix(find(P_mix<Pmax));               %Cutting of the outliers
P = P(1:TotNumCell_Exp);                   %Extraction of a sample of the same size of the experimental one

[Nbin,Pbin]   = hist(P,[Pmin:Pstep:Pmax]); %Pbin: mean protein content of each bin; Nbin: number of cells in each bin

%% Moving window average (over 13 points)

%Experimental
Numbers_Exp_Av13 = zeros(size(Numbers_Exp));

for i=1:length(Numbers_Exp)
    if i<7
        Numbers_Exp_Av13(i) = mean(Numbers_Exp(1:i+6));
    elseif i>length(Numbers_Exp)-6
        Numbers_Exp_Av13(i) = mean(Numbers_Exp(i-6:length(Numbers_Exp)));
    else
        Numbers_Exp_Av13(i) = mean(Numbers_Exp(i-6:i+6));
    end
end

%Simulated
Numbers_Sim_Av13  = zeros(size(Nbin));

for i=1:length(Nbin)
    if i<7
        Numbers_Sim_Av13(i)  = mean(Nbin(1:i+6));
    elseif i>length(Nbin)-6
        Numbers_Sim_Av13(i)  = mean(Nbin(i-6:length(Nbin)));
    else
        Numbers_Sim_Av13(i)  = mean(Nbin(i-6:i+6));
    end
end

%% Sum of Squared Residuals over the 1024 bins

Loss = sum((Numbers_Sim_Av13 - Numbers_Exp_Av13').^2);
