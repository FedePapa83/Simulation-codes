
%MeGro Outputs
lamb_opt=load('Results/Lambda_Exper1.txt');
lamb_opt=[lamb_opt;load('Results/Lambda_Exper2.txt')]; %In the example, the ordering is: 1)-6) Glc 0.05%-5%
                                                        %                                 7) EtOH 2%
rho_opt=load('Results/Rho_Exper1.txt');
rho_opt=[rho_opt; load('Results/Rho_Exper2.txt')];      %In the example, the ordering is: 1)-6) Glc 0.05%-5%
                                                        %                                 7) EtOH 2%

lamb_opt=lamb_opt/60;             %Scaling from  h^-1 to min^-1
n_exper = length(lamb_opt);       %Number of experiments

%K2 limits
K1 = 1;
inf_K2 = lamb_opt./rho_opt;
sup_K2 = K1./(100*rho_opt);

%tau2
tau2=3000;
tau2k=1500;

Lambda = [lamb_opt, 0.85*lamb_opt, 0.40*lamb_opt, 0.10*lamb_opt, 0.05*lamb_opt, 0.025*lamb_opt, 0.005*lamb_opt];
Rho    = [rho_opt, rho_opt, rho_opt, rho_opt, rho_opt, rho_opt, rho_opt];
Tau2   = [tau2*ones(n_exper,1), tau2k*ones(n_exper,1), tau2k*ones(n_exper,1), tau2k*ones(n_exper,1), tau2k*ones(n_exper,1), tau2k*ones(n_exper,1), tau2k*ones(n_exper,1)];

Inf_K2 = [Lambda(:,1)./rho_opt, Lambda(:,2)./rho_opt, Lambda(:,3)./rho_opt, Lambda(:,4)./rho_opt, Lambda(:,5)./rho_opt, Lambda(:,6)./rho_opt, Lambda(:,7)./rho_opt];
Sup_K2 = [sup_K2, sup_K2, sup_K2, sup_K2, sup_K2, sup_K2, sup_K2];

K2     = (Lambda+(1./Tau2))./Rho; 

controlK2 = find( (K2<Inf_K2) | (K2>Sup_K2) );

ValLamb=fopen('Results/iMeGroCyParam/LambdaOpt.txt', 'w');
for i=1:1:n_exper
    fprintf(ValLamb, '%.3f\n', lamb_opt(i)*60);    %The output file LambdaOpt.txt reports the optimal lambda in h^-1
end
fclose(ValLamb);

ValRho=fopen('Results/iMeGroCyParam/RhoOpt.txt', 'w');
for i=1:1:n_exper
    fprintf(ValRho, '%.3e\n', rho_opt(i));         %The output file RhoOpt.txt reports the ratio rho in #rib/#aa
end
fclose(ValRho);

ValK2=fopen('Results/iMeGroCyParam/K2.txt', 'w');
for i=1:1:n_exper
    for j=1:1:7
        fprintf(ValK2, '%.2f\t', K2(i,j));         %The output file K2.txt reports the values of K2 in min^-1        
    end
    fprintf(ValK2, '\n');
end
fclose(ValK2);
